<?php
$db_name = "attendance";
$mysql_username = "root";
//$mysql_username = "remcon";
//$mysql_password = "&cx=Q******";
$mysql_password = "";
$server_name = "localhost:3325";
$conn = mysqli_connect($server_name, $mysql_username, $mysql_password, $db_name);
?>